import os,re 
folder_path = r'D:\New_Journey\Kaggle_competition\AI_mathematical_olympaid\100_days_ML'
with open(r'D:\New_Journey\Coding\Solutions_VS\Hackerrank_practice\DSA\videos_names.txt','r') as file:
    original_name = file.readlines()
file_names = os.listdir(folder_path)
def remove_special_characters(input_string):
    pattern = r'[^a-zA-Z0-9]'
    cleaned_string = re.sub(pattern, '', input_string)
    return cleaned_string
present_count = 0
absent_count = 0
def my_checking(new_name):
    new_name = remove_special_characters(new_name)
    for have_name in file_names:
        modified_name = remove_special_characters(have_name[:-13])
        if (new_name in modified_name) or (modified_name in new_name):
            return have_name
    return False
for count,old_name in enumerate(original_name):
    given_file_path = my_checking(old_name)
    if given_file_path!=False:
        old_path = os.path.join(folder_path, given_file_path)
        second_name = str(count)+"video" + ".mp4"
        new_path = os.path.join(folder_path, second_name)
        try:
            os.rename(old_path, new_path)
            present_count+=1
        except:
            absent_count+=1
            
    else:
        absent_count+=1

print(' Present Count ',present_count)
print(' absent Count ',absent_count)





# for count,old_name in enumerate(original_name):
#     new_name = str(re.sub(symbol_pattern, '_', old_name))[:-10]
#     given_file_path = my_checking(new_name)
#     if given_file_path!=False:
#         old_path = os.path.join(folder_path, given_file_path)
#         second_name = str(count)+"video" + ".mp4"
#         new_path = os.path.join(folder_path, second_name)
#         try:
#             os.rename(old_path, new_path)
#             present_count+=1
#         except:
#             absent_count+=1
#             print(new_name)
            
#     else:
#         absent_count+=1

# print(' Present Count ',present_count)
# print(' absent Count ',absent_count)